GLeagueAlumBoxScoreSimilarityScores:

| PERSON_2_ID   | PERSON_2   | TEAM_ID   | SIMILARITY_SCORE   |
|---------------|------------|-----------|--------------------|