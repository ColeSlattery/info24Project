LeadersTiles:

|   RANK |    TEAM_ID | TEAM_ABBREVIATION   | TEAM_NAME             |   PTS |
|-------:|-----------:|:--------------------|:----------------------|------:|
|      1 | 1610612754 | IND                 | Indiana Pacers        | 123.3 |
|      2 | 1610612738 | BOS                 | Boston Celtics        | 120.6 |
|      3 | 1610612760 | OKC                 | Oklahoma City Thunder | 120.1 |
|      4 | 1610612749 | MIL                 | Milwaukee Bucks       | 119   |
|      5 | 1610612737 | ATL                 | Atlanta Hawks         | 118.3 |

AllTimeSeasonHigh:

|    TEAM_ID | TEAM_ABBREVIATION   | TEAM_NAME   | SEASON_YEAR   |     PTS |
|-----------:|:--------------------|:------------|:--------------|--------:|
| 1610612743 | DEN                 | Nuggets     | 1981-82       | 126.475 |

LastSeasonHigh:

|   RANK |    TEAM_ID | TEAM_ABBREVIATION   | TEAM_NAME             |   PTS |
|-------:|-----------:|:--------------------|:----------------------|------:|
|      1 | 1610612758 | SAC                 | Sacramento Kings      | 120.7 |
|      2 | 1610612744 | GSW                 | Golden State Warriors | 118.9 |
|      3 | 1610612737 | ATL                 | Atlanta Hawks         | 118.4 |
|      4 | 1610612738 | BOS                 | Boston Celtics        | 117.9 |
|      5 | 1610612760 | OKC                 | Oklahoma City Thunder | 117.5 |

LowSeasonHigh:

|    TEAM_ID | TEAM_ABBREVIATION   | TEAM_NAME   | SEASON_YEAR   |    PTS |
|-----------:|:--------------------|:------------|:--------------|-------:|
| 1610610025 | CHS                 | Stags       | 1947-48       | 75.833 |