CumeStatsPlayerGames:

| MATCHUP                          |    GAME_ID |
|:---------------------------------|-----------:|
| 04/10/2024 Mavericks at Heat     | 0022301161 |
| 04/09/2024 Mavericks at Hornets  | 0022301144 |
| 04/07/2024 Rockets at Mavericks  | 0022301131 |
| 04/04/2024 Hawks at Mavericks    | 0022301124 |
| 04/02/2024 Mavericks at Warriors | 0022300589 |
| 03/31/2024 Mavericks at Rockets  | 0022301083 |
| 03/29/2024 Mavericks at Kings    | 0022301073 |
| 03/26/2024 Mavericks at Kings    | 0022301047 |
| 03/25/2024 Mavericks at Jazz     | 0022301041 |
| 03/21/2024 Jazz at Mavericks     | 0022301008 |