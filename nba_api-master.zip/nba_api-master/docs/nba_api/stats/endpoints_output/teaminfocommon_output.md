TeamInfoCommon:

|    TEAM_ID | SEASON_YEAR   | TEAM_CITY   | TEAM_NAME   | TEAM_ABBREVIATION   | TEAM_CONFERENCE   | TEAM_DIVISION   | TEAM_CODE   | TEAM_SLUG   |   W |   L |   PCT |   CONF_RANK |   DIV_RANK |   MIN_YEAR |   MAX_YEAR |
|-----------:|:--------------|:------------|:------------|:--------------------|:------------------|:----------------|:------------|:------------|----:|----:|------:|------------:|-----------:|-----------:|-----------:|
| 1610612742 | 2023-24       | Dallas      | Mavericks   | DAL                 | West              | Southwest       | mavericks   | mavericks   |  50 |  32 |  0.61 |           5 |          1 |       1980 |       2023 |

TeamSeasonRanks:

|   LEAGUE_ID |   SEASON_ID |    TEAM_ID |   PTS_RANK |   PTS_PG |   REB_RANK |   REB_PG |   AST_RANK |   AST_PG |   OPP_PTS_RANK |   OPP_PTS_PG |
|------------:|------------:|-----------:|-----------:|---------:|-----------:|---------:|-----------:|---------:|---------------:|-------------:|
|          00 |       22023 | 1610612742 |          7 |    117.9 |         21 |     42.9 |         19 |     25.7 |             20 |        115.6 |

AvailableSeasons:

|   SEASON_ID |
|------------:|
|       21980 |
|       21981 |
|       21982 |
|       21983 |
|       41983 |
|       21984 |
|       41984 |
|       21985 |
|       41985 |
|       21986 |