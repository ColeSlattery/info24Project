AwayTeam:

|    GAME_ID |    TEAM_ID | TEAM_CITY   | TEAM_NAME   |   PERSON_ID | PLAYER_FIRST   | PLAYER_LAST   |   IN_TIME_REAL |   OUT_TIME_REAL |   PLAYER_PTS |   PT_DIFF |   USG_PCT |
|-----------:|-----------:|:------------|:------------|------------:|:---------------|:--------------|---------------:|----------------:|-------------:|----------:|----------:|
| 0022300061 | 1610612747 | L.A. Lakers | Lakers      |        2544 | LeBron         | James         |              0 |            3530 |            4 |        -4 |     0.2   |
| 0022300061 | 1610612747 | L.A. Lakers | Lakers      |        2544 | LeBron         | James         |           6794 |           10450 |            4 |        -2 |     0.308 |
| 0022300061 | 1610612747 | L.A. Lakers | Lakers      |        2544 | LeBron         | James         |          13130 |           17560 |            2 |         5 |     0.095 |
| 0022300061 | 1610612747 | L.A. Lakers | Lakers      |        2544 | LeBron         | James         |          20620 |           23520 |            7 |         8 |     0.333 |
| 0022300061 | 1610612747 | L.A. Lakers | Lakers      |        2544 | LeBron         | James         |          25160 |           28050 |            4 |         0 |     0.3   |
| 0022300061 | 1610612747 | L.A. Lakers | Lakers      |      203076 | Anthony        | Davis         |              0 |            5500 |            6 |       -11 |     0.391 |
| 0022300061 | 1610612747 | L.A. Lakers | Lakers      |      203076 | Anthony        | Davis         |           8890 |           13130 |           11 |         5 |     0.375 |
| 0022300061 | 1610612747 | L.A. Lakers | Lakers      |      203076 | Anthony        | Davis         |          14400 |           20620 |            0 |        -3 |     0.185 |
| 0022300061 | 1610612747 | L.A. Lakers | Lakers      |      203076 | Anthony        | Davis         |          23520 |           28050 |            0 |        -8 |     0.067 |
| 0022300061 | 1610612747 | L.A. Lakers | Lakers      |     1626156 | D'Angelo       | Russell       |              0 |            3530 |            0 |        -4 |     0.2   |

HomeTeam:

|    GAME_ID |    TEAM_ID | TEAM_CITY   | TEAM_NAME   |   PERSON_ID | PLAYER_FIRST   | PLAYER_LAST   |   IN_TIME_REAL |   OUT_TIME_REAL |   PLAYER_PTS |   PT_DIFF |   USG_PCT |
|-----------:|-----------:|:------------|:------------|------------:|:---------------|:--------------|---------------:|----------------:|-------------:|----------:|----------:|
| 0022300061 | 1610612743 | Denver      | Nuggets     |      202704 | Reggie         | Jackson       |           3530 |            8890 |            8 |        14 |     0.278 |
| 0022300061 | 1610612743 | Denver      | Nuggets     |      202704 | Reggie         | Jackson       |           9220 |           11940 |            0 |        -4 |     0.273 |
| 0022300061 | 1610612743 | Denver      | Nuggets     |      202704 | Reggie         | Jackson       |          18510 |           24870 |            0 |         1 |     0.095 |
| 0022300061 | 1610612743 | Denver      | Nuggets     |      203484 | Kentavious     | Caldwell-Pope |              0 |            5500 |            5 |        11 |     0.174 |
| 0022300061 | 1610612743 | Denver      | Nuggets     |      203484 | Kentavious     | Caldwell-Pope |           8890 |           20620 |           11 |        -6 |     0.204 |
| 0022300061 | 1610612743 | Denver      | Nuggets     |      203484 | Kentavious     | Caldwell-Pope |          23850 |           28363 |            4 |         5 |     0.133 |
| 0022300061 | 1610612743 | Denver      | Nuggets     |      203932 | Aaron          | Gordon        |              0 |            5500 |            2 |        11 |     0.043 |
| 0022300061 | 1610612743 | Denver      | Nuggets     |      203932 | Aaron          | Gordon        |           9220 |           19250 |            8 |        -5 |     0.159 |
| 0022300061 | 1610612743 | Denver      | Nuggets     |      203932 | Aaron          | Gordon        |          21600 |           23850 |            3 |         0 |     0.143 |
| 0022300061 | 1610612743 | Denver      | Nuggets     |      203932 | Aaron          | Gordon        |          25160 |           28363 |            2 |         0 |     0.182 |