CommonPlayerInfo:

|   PERSON_ID | FIRST_NAME   | LAST_NAME   | DISPLAY_FIRST_LAST   | DISPLAY_LAST_COMMA_FIRST   | DISPLAY_FI_LAST   | PLAYER_SLUG   | BIRTHDATE           | SCHOOL   | COUNTRY   | LAST_AFFILIATION   | HEIGHT   |   WEIGHT |   SEASON_EXP |   JERSEY | POSITION      | ROSTERSTATUS   | GAMES_PLAYED_CURRENT_SEASON_FLAG   |    TEAM_ID | TEAM_NAME   | TEAM_ABBREVIATION   | TEAM_CODE   | TEAM_CITY   | PLAYERCODE   |   FROM_YEAR |   TO_YEAR | DLEAGUE_FLAG   | NBA_FLAG   | GAMES_PLAYED_FLAG   |   DRAFT_YEAR |   DRAFT_ROUND |   DRAFT_NUMBER | GREATEST_75_FLAG   |
|------------:|:-------------|:------------|:---------------------|:---------------------------|:------------------|:--------------|:--------------------|:---------|:----------|:-------------------|:---------|---------:|-------------:|---------:|:--------------|:---------------|:-----------------------------------|-----------:|:------------|:--------------------|:------------|:------------|:-------------|------------:|----------:|:---------------|:-----------|:--------------------|-------------:|--------------:|---------------:|:-------------------|
|     1628369 | Jayson       | Tatum       | Jayson Tatum         | Tatum, Jayson              | J. Tatum          | jayson-tatum  | 1998-03-03T00:00:00 | Duke     | USA       | Duke/USA           | 6-8      |      210 |            6 |        0 | Forward-Guard | Active         | Y                                  | 1610612738 | Celtics     | BOS                 | celtics     | Boston      | jayson_tatum |        2017 |      2023 | N              | Y          | Y                   |         2017 |             1 |              3 | N                  |

PlayerHeadlineStats:

|   PLAYER_ID | PLAYER_NAME   | TimeFrame   |   PTS |   AST |   REB |   PIE |
|------------:|:--------------|:------------|------:|------:|------:|------:|
|     1628369 | Jayson Tatum  | 2023-24     |  26.9 |   4.9 |   8.1 | 0.155 |

AvailableSeasons:

|   SEASON_ID |
|------------:|
|       12017 |
|       22017 |
|       42017 |
|       12018 |
|       22018 |
|       42018 |
|       12019 |
|       22019 |
|       32019 |
|       42019 |