CommonTeamRoster:

|     TeamID |   SEASON |   LeagueID | PLAYER           | NICKNAME   | PLAYER_SLUG      |   NUM | POSITION   | HEIGHT   |   WEIGHT | BIRTH_DATE   |   AGE | EXP   | SCHOOL                        |   PLAYER_ID | HOW_ACQUIRED                             |
|-----------:|---------:|-----------:|:-----------------|:-----------|:-----------------|------:|:-----------|:---------|---------:|:-------------|------:|:------|:------------------------------|------------:|:-----------------------------------------|
| 1610612742 |     2023 |         00 | Dante Exum       | Dante      | dante-exum       |     0 | G          | 6-5      |      214 | JUL 13, 1995 |    28 | 6     | Australian Institute of Sport |      203957 | Signed on 07/14/23                       |
| 1610612742 |     2023 |         00 | Brandon Williams | Brandon    | brandon-williams |    00 | G          | 6-1      |      190 | NOV 22, 1999 |    24 | 1     | Arizona                       |     1630314 | Signed on 12/28/23                       |
| 1610612742 |     2023 |         00 | Jaden Hardy      | Jaden      | jaden-hardy      |     1 | G          | 6-3      |      198 | JUL 05, 2002 |    21 | 1     | NBA G League Ignite           |     1630702 | Draft Rights Traded from SAC on 06/24/22 |
| 1610612742 |     2023 |         00 | Dereck Lively II | Dereck     | dereck-lively-ii |     2 | C          | 7-1      |      230 | FEB 12, 2004 |    20 | R     | Duke                          |     1641726 | Draft Rights Traded from OKC on 07/06/23 |
| 1610612742 |     2023 |         00 | Dwight Powell    | Dwight     | dwight-powell    |     7 | F-C        | 6-10     |      240 | JUL 20, 1991 |    32 | 9     | Stanford                      |      203939 | Traded from BOS on 12/18/14              |
| 1610612742 |     2023 |         00 | Josh Green       | Josh       | josh-green       |     8 | G          | 6-5      |      200 | NOV 16, 2000 |    23 | 3     | Arizona                       |     1630182 | #18 Pick in 2020 Draft                   |
| 1610612742 |     2023 |         00 | A.J. Lawson      | A.J.       | aj-lawson        |     9 | G          | 6-6      |      179 | JUL 15, 2000 |    23 | 1     | South Carolina                |     1630639 | Signed on 12/26/22                       |
| 1610612742 |     2023 |         00 | Tim Hardaway Jr. | Tim        | tim-hardaway-jr  |    10 | G-F        | 6-5      |      205 | MAR 16, 1992 |    32 | 10    | Michigan                      |      203501 | Traded from NYK on 01/31/19              |
| 1610612742 |     2023 |         00 | Kyrie Irving     | Kyrie      | kyrie-irving     |    11 | G          | 6-2      |      195 | MAR 23, 1992 |    32 | 12    | Duke                          |      202681 | Traded from BKN on 02/06/23              |
| 1610612742 |     2023 |         00 | Alex Fudge       | Alex       | alex-fudge       |    17 | F          | 6-8      |      200 | MAY 06, 2003 |    21 | R     | Florida                       |     1641788 | Signed on 03/04/24                       |

Coaches:

|    TEAM_ID |   SEASON |   COACH_ID | FIRST_NAME   | LAST_NAME   | COACH_NAME        |   IS_ASSISTANT | COACH_TYPE                             | SORT_SEQUENCE   |   SUB_SORT_SEQUENCE |
|-----------:|---------:|-----------:|:-------------|:------------|:------------------|---------------:|:---------------------------------------|:----------------|--------------------:|
| 1610612742 |     2023 |     203456 | Jason        | Kidd        | Jason Kidd        |              1 | Head Coach                             |                 |                   1 |
| 1610612742 |     2023 |       1527 | Marko        | Milic       | Marko Milic       |              2 | Assistant Coach                        |                 |                   5 |
| 1610612742 |     2023 |     204007 | Alex         | Jensen      | Alex Jensen       |              2 | Assistant Coach                        |                 |                   5 |
| 1610612742 |     2023 |     201162 | Jared        | Dudley      | Jared Dudley      |              2 | Assistant Coach                        |                 |                   5 |
| 1610612742 |     2023 |     202599 | Darrell      | Armstrong   | Darrell Armstrong |              2 | Assistant Coach                        |                 |                   5 |
| 1610612742 |     2023 |    1641949 | Josh         | Broghamer   | Josh Broghamer    |              2 | Assistant Coach                        |                 |                   5 |
| 1610612742 |     2023 |     204085 | Sean         | Sweeney     | Sean Sweeney      |              2 | Assistant Coach                        |                 |                   5 |
| 1610612742 |     2023 |    1642171 | Keith        | Vaney       | Keith Vaney       |              2 | Assistant Coach                        |                 |                   5 |
| 1610612742 |     2023 |     202102 | Eric         | Hughes      | Eric Hughes       |              2 | Assistant Coach                        |                 |                   5 |
| 1610612742 |     2023 |       1539 | God          | Shammgod    | God Shammgod      |             12 | Assistant Coach for Player Development |                 |                   6 |