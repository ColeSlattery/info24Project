CumeStatsTeamGames:

| MATCHUP                          |    GAME_ID |
|:---------------------------------|-----------:|
| 04/14/2024 Mavericks at Thunder  | 0022301196 |
| 04/12/2024 Pistons at Mavericks  | 0022301181 |
| 04/10/2024 Mavericks at Heat     | 0022301161 |
| 04/09/2024 Mavericks at Hornets  | 0022301144 |
| 04/07/2024 Rockets at Mavericks  | 0022301131 |
| 04/05/2024 Warriors at Mavericks | 0022301097 |
| 04/04/2024 Hawks at Mavericks    | 0022301124 |
| 04/02/2024 Mavericks at Warriors | 0022300589 |
| 03/31/2024 Mavericks at Rockets  | 0022301083 |
| 03/29/2024 Mavericks at Kings    | 0022301073 |