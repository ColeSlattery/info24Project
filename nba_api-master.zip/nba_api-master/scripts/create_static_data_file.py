from tools.stats.static_players_update.update import generate_static_data_file

generate_static_data_file()
